<!DOCTYPE html>
<html>
	<head>
		<title>Control Panel | Edumore Learning</title>
		<style>
		 .logout_para{
			text-align: right;
			margin: 0 1% 0 0;
		 }
		 .certificate_button{
			height: auto;
			width: auto;
			border-radius: 0px;
		 }
		</style>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<!-- to be filled -->
		<meta name="keywords" content=""> 
		<!-- css files -->
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/footer-pic.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/jQuery.lightninBox.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/staff.css" rel="stylesheet" type="text/css" media="all">
		<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all">
	</head>
	<body>
		<?php
			session_start();
			if($_SESSION['admin_login']){
				$admin_user=$_SESSION['admin_login'];
				}
			else{
				header("Location: admin-panel.php");
			}
		?>
		<div class="container-fluid">
		  <div class="row">
			<div class="col-sm-12" style="background-color: #400000; font-size: 25px; padding: 5px; color: #fff; text-align: center; margin:10px 0 10px 0;">ADMIN PANEL</div>
		  </div>
		</div>
		<h3 align="center"><font color="#008000">Welcome <?php echo $admin_user; ?>!</font></h3>
		<p class="logout_para" title="Logout"><a href="admin_logout.php" class="btn btn-info"><span class="glyphicon glyphicon-off"></span> Logout </a></p>
		<div class="container-fluid">
		  <div class="row">
			<div class="col-sm-12" style="background-color: #804000; font-size: 25px; padding: 5px; color: #fff; text-align: center; margin:10px 0 10px 0;">Upload Certificate</div>
		  </div>
		</div>
		<?php
			
		?>
		<div class="container">
			<form method="post" action="upload-certificate-status.php" class="form-horizontal career_form_container">
				<div class="form-group">
					<label class="control-label col-sm-3" for="registration_no">Registration No:<span>*</span></label>
					<div class="col-sm-9">
						<input type="text" name="registration_no" class="form-control" id="registration_no" required="required" placeholder="Enter Registration No"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="student_name">Student Name:<span>*</span></label>
					<div class="col-sm-9">
						<input type="text" name="student_name" class="form-control" id="student_name" required="required" placeholder="Enter Student Name"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="father_name">Father's Name:<span>*</span></label>
					<div class="col-sm-9">
						<input type="text" name="father_name" class="form-control" id="father_name" required="required" placeholder="Enter Father Name"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="course_name">Course Name:<span>*</span></label>
					<div class="col-sm-9">
						<input type="text" name="course_name" class="form-control" id="course_name" required="required" placeholder="Enter Course Name"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="course_duration">Course Duration:<span>*</span></label>
					<div class="col-sm-9">
						<input type="text" name="course_duration" class="form-control" id="course_duration" required="required" placeholder="Enter Course Duration"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="marks_obtained">Marks Obtained:<span>*</span></label>
					<div class="col-sm-9">          
						<input type="number" name="marks_obtained" class="form-control" id="marks_obtained" required="required" placeholder="Enter Obtained Marks"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="date_of_issue">Date Of Issue:<span>*</span></label>
					<div class="col-sm-9">          
						<input type="date" name="date_of_issue" class="form-control" id="date_of_issue" required="required"/>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="certificate_status">Certificate Status:<span>*</span></label>
					<div class="col-sm-9">          
						<select name="certificate_status" class="form-control" id="certificate_status" required="required">
							<option value="">--- Select Status ---</option>
							<option value="Active">Active</option>
							<option value="Inactive">Inactive</option>
							<option value="Pending">Pending</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="submitted_by">Submitted By:</label>
					<div class="col-sm-9">          
						<input type="text" name="submitted_by" class="form-control" id="submitted_by" value="Er. Arun kumar" readonly="readonly"/>
					</div>
				</div>
						
				<div class="form-group">        
					<div class="col-sm-offset-3 col-sm-9">
						<button type="submit" class="btn btn-success btn-sm">Upload Certificate</button>
						<button type="reset" class="btn btn-primary btn-sm">Clear</button>
					</div>
				</div>
			</form>
		</div>
	</body>
</html>