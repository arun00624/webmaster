<!DOCTYPE html>
<html>
	<head>
		<title>Java Developer/Java SE/java EE/java ME Training | Edumore Learning</title>
		<link rel="icon" href="images/edumore_favicon.png" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="css/course_style.css">
	</head>
	<body>	
		<?php include 'header1.php'; ?>
		<div class="container-fluid">
			<p class="course_heading">Our Java Developer Training</p>
			<div class="row">
				<div class="col-sm-12">
					<img src="images/course_check/java_developer1.jpg" alt="java_developer_description" class="img-responsive"/>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-12">
					<h2 class="course_intro">Java introduction</h2>
					<p><b>1) </b>Java is a high level, robust, secured and object-oriented programming language founded by James Gosling, Mike Sheridan, and Patrick Naughton.</p>
					<p><b>2) </b>Java originally developed by Sun Microsystems and released in 1995.</p>
					<p><b>3) </b>Firstly, it was called "Greentalk" by James Gosling and file extension was .gt.</p>
					<p><b>3) </b>In 1995, Oak was renamed as "Java" because it was already a trademark by Oak Technologies.</p>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-6">
					<h2 class="course_intro">What is java?</h2>
					<p>Java is a simple, object-oriented, secured, robust, concurrent and general purpose programming language. Some other important features of java are multithreaded, dynamic, architecutre-neutral, secured, portable, interactive and high performance. Java was developed by Sun Microsystems in 1995 since then it has become very popular due to its features like platform independent and robust in It looks like unbelievable that today, around 1.2 billion desktops run java.</p>
				</div>
				<div class="col-sm-6">
					<img src="images/course_check/java_developer2.png" alt="java_description" class="img-responsive"/>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-6">
					<img src="images/course_check/java_developer3.jpeg" alt="java_description" class="img-responsive"/>
				</div>
				<div class="col-sm-6">
					<h2 class="course_intro">What are the usage of java?</h2>
					<p>&#9758; Desktop Applications such as acrobat reader, media player, antivirus etc</p>
					<p>&#9758; Web Applications such as irctc.co.in</p>
					<p>&#9758; Enterprise Applications such as banking applications</p>
					<p>&#9758; Mobile</p>
					<p>&#9758; Embedded System</p>
					<p>&#9758; Smart Card</p>
					<p>&#9758; Robotics</p>
					<p>&#9758; Games etc.</p>
				</div>
			</div>
			<p class="register_c_button">
               <a href="student-registration.php" class="btn btn-outlined btn-theme" data-wow-delay="0.7s">Register Yourself For Java &rarr;</a>
            </p>
		</div>
		<div class="content">
		</div>
		<footer id="myFooter">
			<div class="container">
				<div class="row">
					<div class="col-sm-3 myCols">
						<h5>Home</h5>
						<ul>
							<li><a href="index.php">Home Page</a></li>
							<li><a href="index.php#team">Our Team Members</a></li>
							<li><a href="index.php#portfolio">Our Portfolio</a></li>
						</ul>
					</div>
					<div class="col-sm-3 myCols">
						<h5>About us</h5>
						<ul>
							<li><a href="index.php#about">About Training Centre</a></li>
							<li><a href="index.php#contact">Contact us</a></li>
							<li><a href="index.php#footer">Reviews</a></li>
						</ul>
					</div>
					<div class="col-sm-3 myCols">
						<h5>Courses Offered</h5>
						<ul>
							<li><a href="index.php#service">Software Training programs</a></li>
							<li><a href="index.php#service">Networking Programs</a></li>
							<li><a href="index.php#service">Accounts Training programs</a></li>
						</ul>
					</div>
					<div class="col-sm-3 myCols">
						<h5>Others</h5>
						<ul>
							<li><a href="check-your-certificate-online.php">verify certificate</a></li>
							<li><a href="student-registration.php">Student Registration</a></li>
							<li><a href="http://edumorelearning.blogspot.in/">Blog</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="social-networks">
				<a href="https://twitter.com/edumoreindia" class="twitter"><i class="fa fa-twitter"></i></a>
				<a href="https://www.facebook.com/6WeeksProjectTraining/" class="facebook"><i class="fa fa-facebook-official"></i></a>
				<a href="https://plus.google.com/+EdumorelearningIT" class="google"><i class="fa fa-google-plus"></i></a>
			</div>
			<div class="footer-copyright">
				<p>Copyright © 2017 @edumorelearning</p>
			</div>
		</footer>
	</body>
</html>
	