<!DOCTYPE html>
<html>
	<head>
		<title>ADMIN LOGIN PORTAL | Edumore Learning</title>
		<link rel="stylesheet" type="text/css" href="css/login_style.css">
		<link rel="shortcut icon" href="images/admin_panel_favicon.png" type="image/x-icon">
		<!--<link rel="icon" href="images/edumore_favicon.png" type="image/x-icon">
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/footer-pic.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/jQuery.lightninBox.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/staff.css" rel="stylesheet" type="text/css" media="all">
		<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all">
		<link href="css/style.css" rel="stylesheet" type="text/css" media="all">-->
	</head>
	<body>
		<hr width="100%"/>
		<h2 align="center">Welcome to Edumore Admin Panel</h2>
		<hr width="100%"/>
		<form class="modal-content animate" action="admin_login.php" method="POST">
			<div class="imgcontainer">
			  <img src="images/edumore_logo.png" alt="edumore_logo" class="avatar">
			</div>
			<hr/>
			<div class="container">
			  <label for="username"><b>Username</b></label>
			  <input type="text" name="username" id="username" placeholder="Enter Username" autofocus="autofocus" autocomplete="off"/>
			  <label for="password"><b>Password</b></label>
			  <input type="password" name="password" id="password" placeholder="Enter Password" autocomplete="off"/>
			  <button type="submit">Login</button>
			</div>
	  </form>
	  <hr width="100%"/>
	</body>
</html>