<!DOCTYPE html>
<html>
	<head>
		<title>Certificate Upload status</title>
	</head>
	<body>
<?php
	$registration_no=$_REQUEST['registration_no'];
	$student_name=$_REQUEST['student_name'];
	$father_name=$_REQUEST['father_name'];
	$course_name=$_REQUEST['course_name'];
	$course_duration=$_REQUEST['course_duration'];
	$marks_obtained=$_REQUEST['marks_obtained'];
	$date_of_issue=$_REQUEST['date_of_issue'];
	$certificate_status=$_REQUEST['certificate_status'];
	$submitted_by=$_REQUEST['submitted_by'];
	
	//include database
	include 'edumore_config.php';
	$certificate_db=mysqli_connect($server_name,$user_name,$user_password,$database_name);
	//insert form data
	$certificate_query="INSERT INTO `certificates`(`registration_no`, `student_name`, `father_name`, `course_name`, `course_duration`, `marks_obtained`, `date_of_issue`, `certificate_status`, `submitted_by`, `upload_date_time`) VALUES ('$registration_no','$student_name','$father_name','$course_name','$course_duration',$marks_obtained,'$date_of_issue','$certificate_status','$submitted_by',NOW())";
	mysqli_query($certificate_db,$certificate_query);
	$affected_rows=mysqli_affected_rows($certificate_db);
	//check affected rows
	if($affected_rows==1){
		include 'header1.php';
		echo "<h3 align='center'><font color='#00ff40'>&#x2714; Successfully Uploaded!!</font></h3>";
	}
	else{
		include 'header1.php';
		echo "<h3 align='center'><font color='#ff0000'>&#x2716; Error</font></h3>";
	}
?>

</body>
</html>