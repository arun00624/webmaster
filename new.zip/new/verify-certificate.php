<!DOCTYPE html>
<html>
	<head>
		<title>Student Certificate Status | Edumore Learning</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<!-- to be filled -->
		<meta name="keywords" content=""> 
		<!-- css files -->
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/footer-pic.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/jQuery.lightninBox.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/staff.css" rel="stylesheet" type="text/css" media="all">
		<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all">
		<link rel="icon" href="images/verified_glyphicon.png" type="image/x-icon">
		<style>
			th,td{
				text-transform: uppercase;
			}
		</style>
	</head>
	<body>
		<?php
			$registration_no=$_REQUEST['registration_no'];
			include 'edumore_config.php';
			$verified_db=mysqli_connect($server_name,$user_name,$user_password,$database_name);
			$verified_query="SELECT * from certificates where registration_no='$registration_no'";
			$verified_result=mysqli_query($verified_db,$verified_query);
			if(mysqli_num_rows($verified_result)>0){
				while($verified_ans=mysqli_fetch_assoc($verified_result)){
					$registration_no=$verified_ans['registration_no'];
					$student_name=$verified_ans['student_name'];
					$father_name=$verified_ans['father_name'];
					$course_name=$verified_ans['course_name'];
					$course_duration=$verified_ans['course_duration'];
					$marks_obtained=$verified_ans['marks_obtained'];
					$date_of_issue=$verified_ans['date_of_issue'];
					$certificate_status=$verified_ans['certificate_status'];
					include 'header1.php';
					echo "<div class='container-fluid'>
							<div class='row'>
								<div class='col-sm-12' style='background-color: #00ffff; font-size: 25px; padding: 5px; text-align: center; color: #008000;'>&#x2714; Certificate Verified</div>
							</div>
					</div>
					<div class='container'>
						<table class='table table-bordered table-striped'>
							<thead>
								<tr>
									<th>REGISTRATION NO: </th>
									<th>$registration_no</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th>STUDENT NAME: </th>
									<td>$student_name</td>
								</tr>
								<tr>
									<th>FATHER'S NAME: </th>
									<td>$father_name</td>
								</tr>
								<tr>
									<th>COURSE NAME: </th>
									<td>$course_name</td>
								</tr>
								<tr>
									<th>COURSE DURATION: </th>
									<td>$course_duration</td>
								</tr>
								<tr>
									<th>MARKS OBTAINED: </th>
									<td>$marks_obtained/100</td>
								</tr>
								<tr>
									<th>DATE OF ISSUE: </th>
									<td>$date_of_issue</td>
								</tr>
								<tr>
									<th>STATUS: </th>
									<th><font color='#008000'>$certificate_status</font></th>
								</tr>
								<tr>
									<th><font color='#004000'>SUBMITTED BY: </font></th>
									<th><font color='#004000'>ER. ARUN KUMAR</font></th>
								</tr>
							</tbody>
						</table>
					</div>"; 
				}
			}
			else{
				include 'header1.php';
				echo "<h2 style='text-align: center; color: #ff8000;'><p>Error!!</p><p>Student doesn't exist in our database</p><p>Please contact to edumore team member.</p></h2>";
			}
		?>
		
	</body>
</html>