<?php
    $server_name="localhost";
	$user_name="root";
	$user_password="";
	$database_name="edumore";
?>