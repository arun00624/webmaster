<?php
 
 echo "<h1>This File doesn't exist on my server</h1>";
 
?>