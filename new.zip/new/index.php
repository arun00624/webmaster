<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Best Php, Java, Networking, Tally Training in Delhi/NCR</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<!-- to be filled -->
		<meta name="Description" content="At Edumore Learning we provide web development training,Networking and Computers Basic course, edumore learning is one of the best results-oriented Web Development Training Institute">
        <meta name="Keywords" content="Php Training In ghaziabad, Java training in ghaziabad, computer training center in ghaziabad,computer training center, best computer training center in delhi NCR,ccna training,what is tally, php training, php online training,php training center in Delhi NCR, online teaching courses, train to teach, Software Training Institute,Java, Php, Networking, Tally, MIS, GST, autocad, photoshop">
		<!-- css files -->
        <link rel="icon" href="images/edumore_favicon.png" type="image/x-icon">
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/footer-pic.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/jQuery.lightninBox.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/staff.css" rel="stylesheet" type="text/css" media="all">
		<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all">
		<link href="css/style.css" rel="stylesheet" type="text/css" media="all">
		<!---Enquiry Form Api--->
		
		<!---->
		<!-- /css files -->
	    
	    <!--Google Analytice code --->
	    
	    <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-51673225-1"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'UA-51673225-1');
        </script>
        	<!--social icon links -->
	<link rel="stylesheet" type="text/css" href="https://cdn.rawgit.com/vaakash/socializer/a4c672bf/css/socializer.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
	<!--- End social links -->
	<!--Banner css and js -->
		<link rel="stylesheet" type="text/css" href="slider.css">
		<script src="slider.js"></script>
		<!-- js and css -->
		<!-- /css files -->
	</head>
	<body>
	    <!--- Social icons -->
	   <div class="sr-sharebar sr-sb-vl sr-sb-right"><div class="socializer" data-features="32px,squircle-2,zoom,vertical,icon-white,sw-icon-1,pad" data-sites="facebook,googleplus,linkedin,twitter,email" data-meta-link="" data-meta-title="" data-meta-facebook="https://www.facebook.com/6WeeksProjectTraining/" data-meta-googleplus="https://plus.google.com/+EdumorelearningIT" data-meta-linkedin="https://in.linkedin.com/company/edumore-learning---india" data-meta-twitter="https://twitter.com/edumoreindia" data-meta-email="mailto:info@edumorelearning.com"></div></div>
        <!--Social icons -->
		<!-- navigation -->
		<div class="navbar-wrapper">
			<div class="container-fluid">
				<nav class="navbar navbar-inverse navbar-static-top">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index"><h1 class="edumore_label">Edumore Learning</h1></a>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a href="index" class="page-scroll" data-hover="Home">Home</a></li>
							<li><a href="#about" class="page-scroll" data-hover="About">About</a></li>
							<li><a href="#service" class="page-scroll" data-hover="Services">Courses</a></li>
							<li><a href="#contact" class="page-scroll" data-hover="Contact">Contact</a></li>
							<li><a href="http://edumorelearning.blogspot.in/" class="page-scroll" data-hover="Edumore Blog" target="_blank">Blog</a></li>
							<li><a href="current-openings.php" class="page-scroll" data-hover="Careers">Careers</a></li>
							<li><a href="student-registration" class="page-scroll" target="_blank">Registration</a></li>
							<li><a href="check-your-certificate-online" class="page-scroll" target="_blank">Certification</a></li>
							<li><a href="registration-status" class="page-scroll" target="_blank">Status</a></li>
						</ul>
					</div>
				</nav>
			</div>	
		</div>
		<!-- /navigation -->
<!-- banner section -->
		<div class="manage_banner_height"></div>
		<div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:1300px;height:500px;overflow:hidden;visibility:hidden;">
			<!-- Loading Screen -->
			<div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
				<img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
			</div>
			<div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1300px;height:500px;overflow:hidden;">
				<div data-p="225.00">
					<img data-u="image" src="img/banner1.png" />
				</div>
				<div data-p="225.00">
					<img data-u="image" src="img/banner2.png"/>
				</div>
				<div data-p="225.00">
					<img data-u="image" src="img/banner3.png"/>
				</div>
				<div data-p="225.00">
					<img data-u="image" src="img/banner4.png"/>
				</div>
				<div data-p="225.00">
					<img data-u="image" src="img/banner5.png"/>
				</div>
			</div>
			<!-- Bullet Navigator -->
			<div data-u="navigator" class="jssorb032" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
			<div data-u="prototype" class="i" style="width:16px;height:16px;">
				<svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
				<circle class="b" cx="8000" cy="8000" r="5800"></circle>
				</svg>
			</div>
		</div>
		<!-- Arrow Navigator -->
		<div data-u="arrowleft" class="jssora051" style="width:65px;height:65px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
		<svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
		<polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
		</svg>
		</div>
		<div data-u="arrowright" class="jssora051" style="width:65px;height:65px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
		<svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
		<polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
		</svg>
		</div>
		</div>
		<script type="text/javascript">jssor_1_slider_init();</script>
		<!-- /banner section -->
		<!-- info section -->
		<section class="info-w3l" id="info" data-aos="zoom-in">
			<div class="col-lg-4 col-md-4 col-sm-12 info-wthree1">
				<div class="col-xs-2">
					<i class="fa fa-line-chart" aria-hidden="true"></i>
				</div>
				<div class="col-xs-10">
					<div class="info-agile">
						<h3>Training and Internship</h3>
						<p>Edumore Learning campus training program is a platform for providing comprehensive training on Software, Hardware & Networking and other latest technologies to college students from different technical domains like Engineering, B.Sc/M.Sc, BCA/MCA, etc. within their college premises.</p>
					</div>
				</div>
				<div class="clearfix"></div>
				<hr>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12 info-wthree2">
				<div class="col-xs-2">
					<i class="fa fa-connectdevelop" aria-hidden="true"></i>
				</div>
				<div class="col-xs-10">
					<div class="info-agile">
						<h3>Web Development</h3>
						<p>At Edumore Learning we provide web development,Networking and Basic Computer training, edumore learning is one of the best result oriented Web Development Training Institute in Delhi NCR, offers best practically, experimental knowledge in Web Development in Delhi NCR.</p>
					</div>
				</div>
				<div class="clearfix"></div>
				<hr>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12 info-wthree3">
				<div class="col-xs-2">
					<i class="fa fa-globe" aria-hidden="true"></i>
				</div>
				<div class="col-xs-10">
					<div class="info-agile">
						<h3>Digital marketing</h3>
						<p>At Edumore Learning, We provide digital marketing services to small businesses and marketing managers to improve their online presence and start generating new business. We have included a management team of dynamic, experienced, professionals and creative digital marketing experts.</p>
					</div>
				</div>
				<div class="clearfix"></div>
				<hr>
			</div>
			<div class="clearfix"></div>
		</section>
		<!-- /info section -->
		<!-- services section -->
		<section class="service-w3l" id="service">
			<div class="container">
				<div class="col-lg-4 col-md-12 col-sm-12" data-aos="flip-up">
					<h3>Courses Offered</h3>
					<p class="serv-p1">At Edumore Learning we provide wide variety of courses representing different technologies and infrastructures</p>
				</div>
				<!--- edumore schema --addon 24 jan 2018 by arun --->
				<script type="application/ld+json">
                  {
                    "@context": "http://schema.org",
                    "@type": "Blog",
                    "url": "http://edumorelearning.blogspot.in/"
                  }
                </script>
                <script type="application/ld+json">
                  {
                    "@context": "http://schema.org",
                    "@type": "Organization",
                    "name": "Edumore Learning",
                    "url": "https://www.edumorelearning.com",
                    "sameAs": [
                      "https://www.facebook.com/6WeeksProjectTraining/",
                      "https://plus.google.com/+EdumorelearningIT",
                      "https://twitter.com/edumoreindia"
                    ]
                  }
                </script>
				<div class="col-lg-8 col-md-12 col-sm-12">
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="#">
							<img src="images/all_courses/amazon-aws.png" alt="amazon_aws_training_by_edumore" title="Amazon Aws Training"/>
							<p class="serv-p2"><b>AWS</b> is a comprehensive, evolving cloud computing platform provided by Amazon. It provides a mix of infrastructure as a service (IaaS), platform as a service (PaaS) and packaged software as a service (SaaS) offerings.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="#">Read More >></a></center>
					</div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="#">
							<img src="images/all_courses/microsoft-azure.png" alt="microsoft_azure_training_by_edumore" title="Microsoft Azure Training"/>
							<p class="serv-p2"><b>Microsoft Azure</b>, formerly known as <b>Windows Azure</b>, is Microsoft's public cloud computing platform. It provides a range of cloud services, including those for compute, analytics, storage and networking.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="c-language-training">Read More >></a></center>
					</div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/angular-node.png" alt="Angular_Node.js_training_by_edumore" title="Angular And Node.js Training"/>
							<p class="serv-p2"><b>Node.js and AngularJS</b> both are developed to build web applications using JavaScript, both follow the syntax of JavaScript but they are quite different in their architecture and working.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="#">Read More >></a></center>
					</div>
					<div class="clearfix"></div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="c-language-training">
							<img src="images/all_courses/c_programmin.png" alt="c_language_training_by_edumore" title="C Language"/>
							<!--<h4>C Language</h4>-->
							<p class="serv-p2">C is a general purpose high level programming language which is developed by Dennis M. Ritche at AT & T Bell Labs, USA in 1972. Initially it was invented to develop UNIX OS and C is successor of BCPL also called B language.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="c-language-training">Read More >></a></center>
					</div>
					<div class="col-xs-4 serv-agile2" data-aos="flip-up">
						<a href="java-developer-training">
							<img src="images/all_courses/java.jpg" alt="java_j2ee_training_by_edumore" title="Java/j2ee"/>
							<!--<h4>JAVA J2EE</h4>-->
							<p class="serv-p2">Java/J2EE is a high level, robust, secured and object-oriented programming language and founder of java was james gosling which is originally developed by Sun Microsystems and released in 1995.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="java-developer-training">Read More >></a></center>
					</div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="php-developer-training">
							<!--<h4>PHP</h4>-->
							<img src="images/all_courses/php.jpg" alt="php_training_by_edumore" title="Php"/>
							<p class="serv-p2">Php stands for <u>H</u>ypertext <u>P</u>re<u>P</u>rocessor and it is an open source server side scripting language. it's widely-used for making dynamic and interactive Web pages and founded by Rasmus Lerdorf in 1994.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="php-developer-training">Read More >></a></center>
					</div>
					<div class="clearfix"></div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/android.png" alt="android_training_by_edumore" title="Android Programming"/>
							<!--<h4>C Language</h4>-->
							<p class="serv-p2">Android is an open source and Linux-based operating system for mobile devices such as tablet computers and smartphones, Android was founded by Andy Rubin in october 2003 in Palo Alto, California, United States.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile2" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/dotnet.png" alt="asp_dotnet_training_by_edumore" title="Asp.net"/>
							<!--<h4>JAVA J2EE</h4>-->
							<p class="serv-p2">ASP.NET is a open source server-side web framework designed and developed by Microsoft. Asp.net was first released in January 2002 and it is used to build dynamic websites, web applications and web services.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="python-training.php">
							<img src="images/all_courses/python.png" alt="python_training_by_edumore" title="Python"/>
							<!--<h4>C Language</h4>-->
							<p class="serv-p2"><b>Python</b> is a general-purpose interpreted, interactive object-oriented and high-level programming language. it was created by <b>Guido Van Rossum</b> during 1985-1990. it support automatic garbage collection.</b></p>
						</a>
						<center><a class="btn btn-success btn-sm" href="c-language-training.php">Read More >></a></center>
					</div>
					<div class="clearfix"></div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="#">
							<img src="images/all_courses/digital-marketing.png" alt="digital_marketing_by_edumore" title="Digital Marketing"/>
							<p class="serv-p2">SEO stands for Search Engine Optimization, it is the process to optimize a website for getting higher ranking when users search keywords related to their product and services and through organic search engine results.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="">
							<!--<h4>PHP</h4>-->
							<img src="images/all_courses/autocad.png" alt="autocad_training_by_edumore" title="AutoDesk Autocad"/>
							<p class="serv-p2"><b>CAD</b> is a 2D and 3D computer aided drafting software application used in architecture, construction, and manufacturing to assist in the preparation of blueprints. Professionals who use AutoCAD are often referred to as drafters.</p>
						</a>
						<center><a class="btn btn-success btn-sm" href="digital-marketing-training.php">Read More >></a></center>
					</div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/ccna.png" alt="ccna_training_by_edumore" title="Cisco Certified Network Associate"/>
							<!--<h4>C Language</h4>-->
							<p class="serv-p2">CCNA stands for Cisco Certified Network Associate. CCNA was founded in 1998 by cisco systems and it is used for network routing and switching, security and troubleshoooting and specially used for WAN technology.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="clearfix"></div>
					<div class="col-xs-4 serv-agile2" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/ccnp.jpg" alt="ccnp_training_by_edumore" title="Cisco Certified Network Professional"/>
							<!--<h4>JAVA J2EE</h4>-->
							<p class="serv-p2">CCNP stands for Cisco Certified Network Professional. CCNP is used to work collaboratively with specialist on advanced security, develop, maintain, troubleshooting LAN and WANs. CCNP work on larger networks than a CCNA.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="">
							<!--<h4>PHP</h4>-->
							<img src="images/all_courses/mcsa.png" alt="mcsa_training_by_edumore" title="Microsoft Certified Solutions Associate"/>
							<p class="serv-p2">MCSA stands for Microsoft Certified Solutions Associate and now it is formerly known as Microsoft Certified Systems Administrator. MCSA include Windows 10, Office 365, and Microsoft Server 2012 or 2016.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/rhce.png" alt="rhce_training_by_edumore" title="Red Hat Certified Engineer"/>
							<!--<h4>C Language</h4>-->
							<p class="serv-p2">RHCE is a mid to advanced-level certification that cover the topics in the RHCSA certification such as security and installing common enterprise networking services. To achieve the RHCE certification, you must pass the RHCSA exam.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="clearfix"></div>
					<div class="col-xs-4 serv-agile2" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/aplus_hardware.jpg" alt="aplus_hardware_training_by_edumore" title="A+ Hardware"/>
							<!--<h4>JAVA J2EE</h4>-->
							<p class="serv-p2">A+ is a fundamental course for candidates willing to make their careers in field of Hardware. A+ covers basics of hardware, PC assembling and Installation of operating system, understand Operating System Fundamentals.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="">
							<!--<h4>PHP</h4>-->
							<img src="images/all_courses/mis_excel.png" alt="mis_excel_training_by_edumore" title="Management Information System"/>
							<p class="serv-p2">A management information system(MIS) is a computerized study of people, technology, organization and relationship. Firms uses MIS professionals to calculate the benefits from investment in personnel.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="">
							<!--<h4>PHP</h4>-->
							<img src="images/all_courses/gst.jpg" alt="tally_gst_aining_by_edumore" title="Goods and Services Tax"/>
							<p class="serv-p2">The GST is a value-added tax levied on most goods and services sold for domestic consumption. The GST is paid by consumers, but it is remitted to the government by the businesses selling the goods and services.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="clearfix"></div>					
					<div class="col-xs-4 serv-agile1" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/ms_office.jpg" alt="ms_office_training_by_edumore" title="Microsoft Office"/>
							<!--<h4>C Language</h4>-->
							<p class="serv-p2">Microsoft Office is an office suite of applications, servers and services developed by Microsoft. It was first announced by Bill Gates on 1 August 1988, at COMDEX in Las Vegas. it first version of Office contained MS Word,Excel and PowerPoint.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile2" data-aos="flip-up">
						<a href="">
							<img src="images/all_courses/tally.png" alt="tally_erp9_training_by_edumore" title="Tally ERP9"/>
							<!--<h4>JAVA J2EE</h4>-->
							<p class="serv-p2">Tally.ERP 9 is the perfect business management solution and GST software. Tally was founded by Shyam Sunder Goyanka and his son Bharat Goyanka in 1986. The headquarter of tally is in Bangalore, Karnataka India.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="col-xs-4 serv-agile3" data-aos="flip-up">
						<a href="">
							<!--<h4>PHP</h4>-->
							<img src="images/all_courses/basic_computer.jpg" alt="basic_computer_training_by_edumore" title="Basic Computer"/>
							<p class="serv-p2">BASIC stands for "Beginner's All-purpose Symbolic Instruction Code." Originally designed as an interactive mainframe timesharing language by John Kemeney and Thomas Kurtz in 1963, it includes knowledge of hardware, software and peripheral devices.</p>
						</a>
						<center><button type="button" class="btn btn-success btn-sm">Read More >></button></center>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
		</section>
		<!-- /services section -->
		<!-- about section -->
		<section class="about-agileits" id="about">
			<div class="container">
				<div class="col-lg-6 col-md-6 col-sm-12 about-w3ls1" data-aos="zoom-in">
					<div class="hover01 column">
						<div>
							<figure>
								<img src="images/about-img.jpg" alt="about edumore learning it training center" class="img-responsive">
							</figure>
						</div>
					</div>		
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 about-w3ls2" data-aos="zoom-in">
					<div class="about-w3l">
						<h3><span class="fa fa-slack" aria-hidden="true"></span> About Edumore Learning</h3>	
						<p>Edumore learning, a pioneer in the field of IT training provides Quality Certification and Skill Enhancement programs leading into career in Software, Hardware and Networking in association with leading Global IT organizations.</p>
						<p>At Edumore learning, we are committed to helping build tomorrow’s business leaders. Dedicated to creating global competence in IT, Business and Accounting, we have designed our courses to be world class, stay industry relevant and market responsive, and most importantly, keep our students way ahead of the rest</p>
						<ul class="about-links">
							<li><a href="#" class="about-link1" data-toggle="modal" data-target="#largeModal">Read More >></a></li>
						</ul>
					</div>	
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" title="About Edumore Learning">About Edumore Learning</h4>
						</div>
						<div class="modal-body">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<img src="images/about_us.png" alt="about edumore learning" class="img-responsive">
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<p class="news-info">Edumore learning, a pioneer in the field of IT training provides Quality Certification and Skill Enhancement programs leading into career in Software, Hardware and Networking in association with leading Global IT organizations.
		 At Edumore learning, we are committed to helping build tomorrow’s business leaders. Dedicated to creating global competence in IT, Business and Accounting, we have designed our courses to be world class, stay industry relevant and market responsive, and most importantly, keep our students way ahead of the rest.Our teaching is modelled to be case-study based and application oriented, where students and faculty evaluate theories and principles in the context of everyday business needs and challenges. Our student-faculty ratio, is one of the healthiest in the industry, and creates the ideal environment for one on one mentoring and academic engagement between the student and faculty. We also encourage joint involvement between students and faculty, in corporate projects and research opportunities.</p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal" title="close">Close</button>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- /about section -->
		<!-- Staff section  -->
		<section class="staff-agileinfo" id="team">
			<div class="container">
				<h3 class="text-center">Our Team Members</h3>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 team-agile1" data-aos="flip-up">
					<div class="view view-eighth">
						<img src="images/team-img1.jpg" alt="atinder_kumar" class="img-responsive"/>
						<div class="mask">
							<h4>Mr. Atinder Kumar</h4>
							<ul class="team-social">
								<li><a href="https://www.facebook.com/atinderchoudhary" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="" target="_blank"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>		
								<li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
							</ul>
							<p class="info">Centre Director</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 team-agile2" data-aos="flip-up">
					<div class="view view-eighth">
						<img src="images/footer-pic4.jpg" alt="" class="img-responsive"/>
						<div class="mask">
							<h4>Name2</h4>
							<ul class="team-social">
								<li><a href="" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="" target="_blank"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>		
								<li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
							</ul>
							<p class="info">Networking Trainer</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 team-agile3" data-aos="flip-up">
					<div class="view view-eighth">
						<img src="images/team-img3.jpg" alt="arun_kumar" class="img-responsive"/>
						<div class="mask">
							<h4>Er. Arun Kumar</h4>
							<ul class="team-social">
								<li><a href="https://www.facebook.com/arunkumar20152014" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://www.youtube.com/channel/UCnvowFeF8CJaCx-Qa3G5vJg" target="_blank"><i class="fa fa-youtube"></i></a></li>
								<li><a href="https://twitter.com/ArunTechsupport" target="_blank"><i class="fa fa-twitter"></i></a></li>		
								<li><a href="https://plus.google.com/u/0/103557513854075860598" target="_blank"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="https://www.linkedin.com/in/arun-kumar-72359b117/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
							</ul>
							<p class="info">Software Trainer</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 team-agile4" data-aos="flip-up">
					<div class="view view-eighth">
						<img src="images/team-img2.jpg" alt="swati_sharma" class="img-responsive"/>
						<div class="mask">
							<h4>Swati Sharma</h4>
							<ul class="team-social">
								<li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>		
								<li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
							</ul>
							<p class="info">HR Executive</p>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</section>
		<!-- subscribe section -->
		<section class="subs jarallax">
			<div class="container">
				<div class="col-lg-6 col-md-6 subs-w3ls1" data-aos="zoom-in">
					<h3>Subscribe To Us</h3>
					<p>Stay connected to Edumore, so that you can receive notifications, latest news or courses offer. Get latest updates on your email regarding courses or other useful information </p>
				</div>
				<div class="col-lg-6 col-md-6 subs-w3ls1" data-aos="zoom-in">
					<div class="subscribe">
						<form action="subscriber" method="post">
							<div class="form-group1">
								<input type="email" class="form-control" id="mail" name="subscriber_email" placeholder="Enter Your Email Address" required="required">
							</div>
							<div class="form-group2">
								<button type="submit" class="btn btn-outline btn-lg">Subscribe</button>
							</div>
							<div class="clearfix"></div>
						</form>
					</div>	
				</div>
				<div class="clearfix"></div>
			</div>
		</section>
		<!-- subscribe section -->
		<!-- contact section -->
		<section class="contact-wthree jarallax" id="contact">
			<div class="container">
				<h3 class="text-center">Contact Us</h3>
				<div class="col-lg-2 col-md-2 col-sm-2" data-aos="zoom-in">
					<img src="images/edumore_building.jpg" alt="Edumore Building" class="img-circle img-responsive">
				</div>
				<div class="col-lg-10 col-md-10 col-sm-10" data-aos="zoom-in">
					<h4>Be In Touch With Us</h4>
					<p class="contact-agile">We are always available</p>
				</div>
				<div class="col-lg-12" data-aos="zoom-in">
					<ul class="contact-info">
						<li>
							<i class="fa fa-phone-square" aria-hidden="true"></i>
							<p class="contact-p1">+91-9871537861 /62/63</p>
							<p class="contact-p2">0120-4166660</p>
						</li>
						<li>
							<i class="fa fa-envelope" aria-hidden="true"></i>
							<p class="contact-p1"><a href="mailto:info@edumorelearning.com">info@edumorelearning.com</a></p>
							<p class="contact-p2"><a href="mailto:info@edumorelearning.in">info@edumorelearning.in</a></p>
						</li>
						<li>
							<i class="fa fa-address-book" aria-hidden="true"></i>
							<p class="contact-p1">94/A, Rana Complex, Grand Trunk Road, Panchsheel Park, </p>
							<p class="contact-p2">Near Bikanervala, Rajendra Nagar, Ghaziabad, Uttar Pradesh 201005</p>
						</li>
					</ul>
				</div>	
				<div class="clearfix"></div>	
				<form action="thanks" method="post">
					<div class="col-lg-4 col-md-4 col-sm-4" data-aos="zoom-in">    
						<div class="control-group form-group">
							<div class="controls">
								<label for="name">Your Name *</label>
								<input type="text" class="form-control" name="user_name" id="name" placeholder="Enter Your Name" required="required"/>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4" data-aos="zoom-in">	
						<div class="control-group form-group">
							<div class="controls">
								<label for="phone">Mobile Number *</label>
								<input type="tel" class="form-control" name="user_mobile_number" id="phone" placeholder="Enter Your Mobile No" required="required"/>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4" data-aos="zoom-in">			
						<div class="control-group form-group">
							<div class="controls">
								<label for="email">Email ID *</label>
								<input type="email" class="form-control" id="email" name="user_email_id" placeholder="Enter Your Email ID" required="required"/>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
					<div class="col-lg-12" data-aos="zoom-in">	
						<div class="control-group form-group">
							<div class="controls">
								<label for="message">Your Message</label>
								<textarea rows="10" cols="100" class="form-control" name="user_message" id="message" placeholder="Drop Your Message Here..." maxlength="999"></textarea>
							</div>
						</div>
						<div id="success"></div>
						<!-- For success/fail messages -->
					</div>
					<div class="col-lg-12" data-aos="zoom-in">	
						<button type="submit" class="btn btn-primary">Send Message &#8594;</button>
					</div>
					<div class="clearfix"></div>	
				</form>	
			</div>
		</section>
		<!-- contact section -->
		<!-- footer section -->
		<section class="footer-wthree">
			<div class="container">
				<div class="col-lg-4 col-md-4 col-sm-12 footer-grid" data-aos="zoom-in">
					<h3>Latest Tweets</h3>
					<span class="line1"></span>
					<ul class="tweet-agile">
						<li>
							<i class="fa fa-twitter-square" aria-hidden="true"></i>
							<p class="tweet-p1"><a href="mailto:info@edumorelearning.com">@EdumoreIndia </a>The way you teach...the knowledge you share..the care you take...<a href="https://goo.gl/LbnXNj">https://goo.gl/LbnXNj</a></p>
						</li>
						<li>
							<i class="fa fa-twitter-square" aria-hidden="true"></i>
							<p class="tweet-p1"><a href="mailto:info@edumorelearning.com">@EdumoreIndia </a>Greeting from edumore learning! Very soon we're organizing a workshop on GST...<a href="https://goo.gl/ZPbRfP">https://goo.gl/ZPbRfP</a></p>
						</li>
					</ul>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 footer-grid" data-aos="zoom-in">
					<span class="line4"></span>
					<h3>Latest Pics</h3>
					<span class="line2"></span>
					<ul class="clearfix demo">
						<li><img src="images/footer-pic3.jpg" alt="php training by edumore" class="img-responsive"/></li>
						<li><img src="images/footer-pic4.jpg" alt="java training by edumore" class="img-responsive"/></li>
						<li><img src="images/footer-pic3.jpg" alt="tally training by edumore" class="img-responsive"/></li>
						<li><img src="images/footer-pic4.jpg" alt="networking by edumore" class="img-responsive"/></li>
					</ul>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 footer-grid" data-aos="zoom-in">
					<span class="line5"></span>
					<h3>Latest News</h3>
					<span class="line3"></span>
					<ul class="footer-news">
						<li>
							<div class="news-content">
								<a href="#" class="news-header" data-toggle="modal" data-target="#news1"><h4>Summer Training 2018</h4></a>
								<p class="news-p1">Edumore provides summer training, winter training, regular training and 6 weeks/months training to the B.E./B.TECH/MCA/BCA students.</p>
								<p class="news-p2">Posted On March 15, 2018</p>
							</div>
							<div class="news-pic">
								<a href="#" data-toggle="modal" data-target="#news1"><img src="images/summer_training_banner.png" alt="6 weeks/months summer training 2018 bby edumore" class="img-responsive"></a>
							</div>
							<div class="clearfix"></div>
						</li>
                        <div class="fb-like" data-href="https://www.facebook.com/6WeeksProjectTraining" data-width="200" data-layout="button_count" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
				<span class="line6"></span>
			</div>
			<p class="copyright">© <?php echo date('Y'); ?> Edumore Learning | All Rights Reserved</p>
			<div class="modal fade" id="news1" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title w3-agile agileits-w3layouts w3layouts">Summer TRAINING BY EDUMORE LEARNING</h4>
						</div>
						<div class="modal-body">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<img src="images/summer_training_banner.png" alt="6 weeks/months summer training 2018 bby edumore" class="img-responsive">
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<p class="news-info">Edumore  is one of the emerging Training Organization in the IT Domain. Edumore provides summer training, winter training, regular training and 6 weeks/months training to the B.E./B.TECH/MCA/BCA. We provide technologies like iPhone Application Training, .NET, ANDROID, Embedded System, Robotics, JAVA, PHP,DEVICE DRIVER, NETWORKING, STAAD PRO, HTML5, SEO, Digital Marketing and many more. Our Courses have not only proved fruitful to Fresher’s in finding the lucrative and desired jobs. But also proved helpful to professionals to touch new heights in their careers.</p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- /footer section -->
		<!-- back to top -->
		<a href="#0" class="cd-top">Top</a>
		<!-- /back to top -->	
		<!-- js files -->
	
		<!-- /js files -->	
		<!-- js files -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/SmoothScroll.min.js"></script>
		<script src="js/modernizr.min.js"></script> 
		<script src="js/jquery.easing.min.js"></script>
		<script src="js/grayscale.js"></script>
		<script src="js/jqBootstrapValidation.js"></script>
		<script src="js/top.js"></script>
		<!-- js for banner section -->
		<script src="js/bgfader.js"></script>
		<script>
			var myBgFader = $('.header').bgfader([
			'images/banner1.jpg',
			'images/banner2.jpg',
			'images/banner3.jpg',
			'images/banner4.jpg',
			], {
			'timeout': 3000,
			'speed': 3000,
			'opacity': 0.4
			})
			myBgFader.start()
		</script>
		<!-- /js for banner section -->
		<!-- js for parallax effect -->
		<script src="js/jarallax.js"></script>
		<script type="text/javascript">
			/* init Jarallax */
			$('.jarallax').jarallax({
				speed: 0.5,
				imgWidth: 1366,
				imgHeight: 768
			})
		</script>
		<!-- /js for parallax effect -->
		<!-- js for footer pic lightbox -->
		<script src="js/jquery.picEyes.js"></script>
		<script>
		$(function(){
			//picturesEyes($('li'));
			$('ul.demo li').picEyes();
		});
		</script>
		<!-- /js for footer pic lightbox -->
		<!-- js for portfolio lightbox -->
		<script src="js/jQuery.lightninBox.js"></script>
		<script type="text/javascript">
			$(".lightninBox").lightninBox();
		</script>
		<!-- /js for portfolio lightbox -->
		<script src='js/aos.js'></script>
		<script src="js/index.js"></script>
		<!-- /js files -->	
		<!--- Social icons --->
		<script src="https://cdn.rawgit.com/vaakash/socializer/a4c672bf/js/socializer.min.js"></script>
        <script>
        (function(){
            socializer( '.socializer' );
        }());
        </script>
		<!--- Social icons --->
	</body>
</html>