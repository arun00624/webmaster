<!DOCTYPE html>
<html>
	<head>
		<title>Registration Status | Edumore Learning</title>
	</head>
	<body>
		<?php
			$student_course=$_REQUEST['student_course'];
			$student_name=$_REQUEST['student_name'];
			$student_mob_no=$_REQUEST['student_mob'];
			$student_email_id=$_REQUEST['student_email'];
			$student_gender=$_REQUEST['student_gender'];
			$student_highest_qualification=$_REQUEST['student_highest_qualification'];
			$student_current_address=$_REQUEST['student_current_address'];
			$student_message=$_REQUEST['student_message'];
			
			/*echo $student_course.'<br/>';
			echo $student_name.'<br/>';
			echo $student_mob_no.'<br/>';
			echo $student_email_id.'<br/>';
			echo $student_gender.'<br/>';
			echo $student_highest_qualification.'<br/>';
			echo $student_current_address.'<br/>';
			echo $student_message.'<br/>'; */
			
			$student_db=mysqli_connect("localhost","root","","edumore");
			$student_query="INSERT INTO student_registration(student_course,student_name,student_mob_no,student_email_id,student_gender,student_qualification,student_address,student_message,student_date_time) VALUES('$student_course','$student_name','$student_mob_no','$student_email_id','$student_gender','$student_highest_qualification','$student_current_address','$student_message',NOW())";
			mysqli_query($student_db,$student_query);
			
			//email data
			$subject = "Edumore Registration Successful";
			$from = 'arun00624@email.com';
			 
			// To send HTML mail, the Content-type header must be set
			$headers  = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			 
			// Create email headers
			$headers .= 'From: '.$from."\r\n".
				'Reply-To: '.$from."\r\n" .
				'X-Mailer: PHP/' . phpversion();
			 
			// Compose a zocub career HTML email message
			$message = "<html>
							<body>
								<p>Dear $student_name!!</p>
								<p>Thank you for applying the $student_course course at Edumore Learning</p>
								<table border=1 align=center style='padding: 50px; border-collapse: collapse; width: 800px; border-color: #ddd;'>
									<tbody>
										<tr style='background-color: #1AB394; height: 35px; color: #fff; font-weight: bold;'>
											<th colspan=2>&#x261B; Student registration details</th>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; width: 350px;'>Your Name</td>
											<td style='padding: 10px;'>$student_name</td>
										</tr>
										<tr>
											<td style='padding: 10px; width: 350px;'>Your Mob No</td>
											<td style='padding: 10px;'>$student_mob_no</td>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; font-weight: bold; width: 350px;'>Your Course</td>
											<td style='padding: 10px; font-weight: bold;'>$student_course</td>
										</tr>
										<tr>
											<td style='padding: 10px; width: 350px;'>Your Email ID</td>
											<td style='padding: 10px;'>$student_email_id</td>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; font-weight: bold; width: 350px;'>Registration Status</td>
											<td style='padding: 10px; font-weight: bold;'>Completed</td>
										</tr>
										<tr style='background-color: #1AB394; height: 35px; color: #fff;'>
											<th colspan=2>&#x26AB; &#x26AB; &#x26AB; &#x26AB; &#x26AB;</th>
										</tr>
									</tbody>
								</table>
								<p>Thank you for applying this course and soon our team member will call you on mobile no $student_mob_no.</p>
								<p style='font-size: 18px; color: #ff0000;'>With best regards<br/><span style='color: #00f;'>Edumore Learning Team</span><br/>
								 <span style='color: #ff0080; font-size: 14px;'>Website: <a href='http://www.edumorelearning.com/' alt='http://www.edumorelearning.com/'/>www.edumorelearning.com</a></span></p>
							</body>
						</html>";
				
				//$email_to_office="edumorelearning@gmail.com";
				$email_to_office="zocubtechnologies@gmail.com";
				$subject_to_office = "New Registration Received of $student_name for $student_course";
				$from = 'arun00624@email.com';
				 
				// To send HTML mail, the Content-type header must be set
				$headers_to_office = 'MIME-Version: 1.0' . "\r\n";
				$headers_to_office.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				 
				// Create email headers
				$headers_to_office .= 'From: '.$from."\r\n".
					'Reply-To: '.$from."\r\n" .
					'X-Mailer: PHP/' . phpversion();
				 
				// send html message to zocub HR Team		
				$message_to_office = "<html>
							<body>
								<h2 align='center'>Application received for $student_course</h2>
								<table border=1 align=center style='padding: 50px; border-collapse: collapse; width: 600px; border-color: #ddd;'>
									<tbody>
										<tr style='background-color: #1AB394; height: 35px; color: #fff; font-weight: bold;'>
											<th colspan=2>Student registration details</th>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; width: 300px;'>Course Name</td>
											<td style='padding: 10px;'>$student_course</td>
										</tr>
										<tr>
											<td style='padding: 10px; width: 300px;'>Candidate Name</td>
											<td style='padding: 10px;'>$student_name</td>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; width: 300px;'>Candidate Mob no</td>
											<td style='padding: 10px;'>$student_mob_no</td>
										</tr>
										<tr>
											<td style='padding: 10px; width: 350px;'>Candidate Email Id:</td>
											<td style='padding: 10px;'>$student_email_id</td>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; width: 300px;'>Candidate Gender</td>
											<td style='padding: 10px;'>$student_gender</td>
										</tr>	
										<tr>
											<td style='padding: 10px; width: 300px;'>Highest Qualification</td>
											<td style='padding: 10px;'>$student_highest_qualification</td>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; width: 300px;'>Candidate Address</td>
											<td style='padding: 10px;'>$student_current_address</td>
										</tr>
										<tr>
											<td style='padding: 10px; font-weight: bold; width: 300px;'>Candidate Message</td>
											<td style='padding: 10px; font-weight: bold;'>$student_message</td>
										</tr>
										<tr style='background-color: #EBEBEB;'>
											<td style='padding: 10px; font-weight: bold; width: 300px;'>Registration Status </td>
											<td style='padding: 10px; font-weight: bold;'>Completed</td>
										</tr>
										<tr style='background-color: #1AB394; height: 35px; color: #fff;'>
											<th colspan=2>&#x26AB; &#x26AB; &#x26AB; &#x26AB; &#x26AB;</th>
										</tr>
									</tbody>
								</table>
								<p style='font-size: 18px; color: #ff0000;'>With best regards<br/><span style='color: #00f;'>Edumore Management Team</span><br/>
								 <span style='color: #ff0080; font-size: 14px;'>Website: <a href='http://www.edumorelearning.com/' alt='http://www.edumorelearning.com/'/>www.edumorelearning.com</a></span></p>
							</body>
						</html>";
						
			if(mail($student_email_id,$subject,$message,$headers))
			{
				mail($email_to_office,$subject_to_office,$message_to_office,$headers_to_office);
				include 'header1.php';
				echo "<h1 align='center'>
						<font style='color: #008000; font-size: 25px;'>
								<p style='font-size: 70px;'>&#x2714;</p>Your have registered successfully!!<p>and registered information has been sent to $student_email_id
						</font>
					</h1>";
			}
			else{
				include 'header1.php';
				echo "<h1 align='center'>
						<font color='#ff0000' style='font-size: 25px;';>  
						  &#x2716; Error!! Registration unsuccessfull, <p>Please check your internet connection</p>
						  <p>Please <a href='student-registration.php' style='text-decoration: none;'>try again</a></p>
						</font>
					</h1>";
			}
		?>
	</body>
</html>