
<?php
		session_start();
		$error="";
		if (empty($_POST['username']) || empty($_POST['password'])) {
			header('Location: admin-panel.php');
			$error = "Username or Password is invalid";
		}
		else
		{ 
			//echo "Hello admin";
			$admin_username=$_REQUEST['username'];
			$admin_password=$_REQUEST['password'];
			//protect data from SQL injection
			$admin_username = stripslashes($admin_username);
			$admin_password = stripslashes($admin_password);
			$admin_username = mysql_real_escape_string($admin_username);
			$admin_password = mysql_real_escape_string($admin_password);
			$admin_username = trim($admin_username);
			$admin_password = trim($admin_password);
			//echo "Hello ".$admin_username.'<br/>';
			//echo "Your Password is: ".$admin_password;
			include 'edumore_config.php';
			$admin_db=mysqli_connect($server_name,$user_name,$user_password,$database_name);
			$admin_query="SELECT * from admin_panel where username='$admin_username' AND password='$admin_password'";
			$admin_result=mysqli_query($admin_db,$admin_query);
			$admin_rows=mysqli_num_rows($admin_result);
			if($admin_rows==1){
				$_SESSION['admin_login']=$admin_username;
				header('Location: welcome.php');
			}
			else{
				$error="Invalid username or password";
				header('Location: admin-panel.php');
			}
			mysql_close($admin_db); // Closing Connection
		}
?>