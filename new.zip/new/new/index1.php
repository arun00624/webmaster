<!DOCTYPE html>
<head>
	 <title>Zocub Technologies :: Our Services</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <!-- Custom CSS -->
    <link href="css/3-col-portfolio.css" rel="stylesheet" type="text/css">
	<style>
		.chip {
			display: inline-block;
			padding: 0 25px;
			height: 50px;
			font-size: 18px;
			line-height: 50px;
			border-radius: 0px;
			background-color: #f1f1f1;
		}
		.closebtn {
			padding-left: 10px;
			color: #888;
			font-weight: bold;
			float: right;
			font-size: 20px;
			cursor: pointer;
		}

		.closebtn:hover {
			color: #000;
		}
	</style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="http://zocub.in/">Zocub Technologies</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="contact_us.php">Contact Us</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Header -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header">Zocub Technologies
                    <small>Our Services</small>
                </h3>
            </div>
        </div>
        <!-- /.row -->

        <!-- Projects Row -->
        <div class="row">
            <div class="col-md-4 portfolio-item">
                <a href="contact_us.php">
                    <img class="img-responsive" src="images/btech_all_projects.jpg" title="All Projects for B.Tech Students" alt="all_projects_of_btech_cse_are_available"/>
                </a>
                <h3><a href="contact_us.php">All B.Tech/CSE Projects</a></h3>
                <p>Zocub Technologies provide the widest list of computer engineering projects for engineering students at affordable price.</p>
            </div>
            <div class="col-md-4 portfolio-item">
                <a href="contact_us.php">
                    <img class="img-responsive" src="images/btech_php_projects.jpg" title="Php Major/Minor Projects for B.Tech Students" alt="b.tech_php_projects"/>
                </a>
                <h3><a href="contact_us.php">Major/Minor Php Project</a></h3>
                <p>Zocub Technologies provide the widest variety of innovative php projects with understandable source code and easy synopsis.</p>
            </div>
            <div class="col-md-4 portfolio-item">
                <a href="contact_us.php">
                    <img class="img-responsive" src="images/online_project_training.jpg" title="Online Project Training of Various Technologies" alt="online_project_training"/>
                </a>
                <h3><a href="contact_us.php">Online Project Training</a></h3>
                <p>Zocub Technologies provide free online project based industrial training on various computer science courses like php, java, web designing and many more.</p>
            </div>
        </div>
        <!-- /.row -->
        <!-- Projects Row -->
        <div class="row">
            <div class="col-md-4 portfolio-item">
                <a href="http://zocub.in">
                    <img class="img-responsive" src="images/book_online_laptop_pc_repairing_at_your_home.jpg" title="Book online Laptop/PC Repairing At Your Home" alt="Book online Laptop/PC Repairing At Your Home"/>
                </a>
                <h3><a href="http://zocub.in">Laptop/PC Repairing</a></h3>
                <p>Book online Laptop/PC repairing at your home by experienced and professional zocub technicians experts in various software/hardware field.</p>
            </div>
            <div class="col-md-4 portfolio-item">
                <a href="contact_us.php">
                    <img class="img-responsive" src="images/technical_video_lectures.jpg" title="Technical/Engineering Video Lectures for B.Tech" alt="Technical/Engineering Video Lectures for B.Tech"/>
                </a>
                <h3><a href="contact_us.php">Technical Video Lectures</a></h3>
                <p>Zocub Technologies provides technical video lectures of complete web designing, java core+advance, Asp.net, DAA, dreamweaver cs4, Data structure , and many more ...</p>
            </div>
            <div class="col-md-4 portfolio-item">
                <a href="contact_us.php">
                    <img class="img-responsive" src="images/all_mobile_pc_softwares.jpg" title="All Software For Laptop/PC Mobiles" alt="All Software For Laptop/PC Mobiles"/>
                </a>
                <h3><a href="contact_us.php">Laptop/PC/Mobile Softwares</a></h3>
                <p>Zocub Technologies serves you a better quality and compatible softwares for your laptop/pc/mobile etc.</p>
            </div>
        </div>
        <hr/>
		<div class="chip">
			<span>Various services offered by zocub technologies</span>
			<span class="closebtn" onclick="this.parentElement.style.display='none'">&times;</span>
		</div>
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Zocub Technologies 2016-2018</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>
    </div>
    <!-- /.container -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
