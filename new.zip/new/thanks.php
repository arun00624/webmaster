<?php
	$user_name=$_REQUEST['user_name'];
	$user_mobile_no=$_REQUEST['user_mobile_number'];
	$user_email_id=$_REQUEST['user_email_id'];
	$user_message=$_REQUEST['user_message'];
	$enquiry_number=substr(uniqid(rand(100,900), true), 0, 5);
	
	$user_message_db=mysqli_connect("localhost","root","","edumore");
	$user_message_query="INSERT INTO users(user_name,user_mobile_no,user_email_id,user_message,user_date_time) VALUES('$user_name','$user_mobile_no','$user_email_id','$user_message',NOW())";
	mysqli_query($user_message_db,$user_message_query);
	
	/* Send mail to user from edumore */
	$subject = "Thank you $user_name for enquiry. your enquiry no is: $enquiry_number";
	/*enter your domain mail id*/
	$from = 'arun00624@email.com';
			 
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			 
			// Create email headers
	$headers .= 'From: '.$from."\r\n".
				'Reply-To: '.$from."\r\n" .
				'X-Mailer: PHP/' . phpversion();
			 
			// Compose a HTML email message
	$message = "<html>
					<body>
						<p>Hi $user_name!!</p>
						<p>Thank you for your enquiry..kindly note down your enquiry no</p>
						<h1>Your Enquiry No is: $enquiry_number<font color='#282887'></font></h1>
						<table border=1 align=center style='padding: 50px; border-collapse: collapse; width: 800px; border-color: #ddd;'>
							<tbody>
								<tr style='background-color: #1AB394; height: 35px; color: #fff; font-weight: bold;'>
									<th colspan=2>&#x261B; Your Message</th>
								</tr>
								<tr>
									<td style='padding: 10px; font-weight: bold; width: 350px;'>Enquiry No</td>
									<td style='padding: 10px; font-weight: bold;'>#$enquiry_number</td>
								</tr>
								<tr style='background-color: #EBEBEB;'>
									<td style='padding: 10px; width: 350px;'>Your  Name</td>
									<td style='padding: 10px;'>$user_name</td>
								</tr>
								<tr>
									<td style='padding: 10px; width: 350px;'>Your Mobile No</td>
									<td style='padding: 10px;'>$user_mobile_no</td>
								</tr>
								<tr style='background-color: #EBEBEB;'>
									<td style='padding: 10px; width: 350px;'>Your Email ID</td>
									<td style='padding: 10px;'>$user_email_id</td>
								</tr>
								<tr style='background-color: #EBEBEB;'>
									<td style='padding: 10px; width: 350px;'>Your Message</td>
									<td style='padding: 10px;'>$user_message</td>
								</tr>
								<tr style='background-color: #1AB394; height: 35px; color: #fff;'>
									<th colspan=2 style='font-size: 20px;'>&#x263B;&#x263B;</th>
								</tr>
							</tbody>
						</table>
								<p><font color='#008000' size='4'>Edumore Management Team</font></p>
								<p align='left'>website: www.edumorelearning.com</p>
								<img src='http://www.edumorelearning.com/pictures/edumore_logo.png' alt='edumore_logo'/>
					</body>
				</html>";
	if(mail($user_email_id,$subject,$message,$headers)){
		include 'header1.php';
		echo "<div class='container-fluid' style='margin-top: 60px; text-align: center;'>
				<div class='alert alert-success alert-dismissable fade in'>
					<strong>&#x2714; Thanks $user_name!</strong> Our team member contact you as soon as possible after discern your information
				</div>
		</div>";
	}
	else{
		echo "<h1 align='center'><font color='#ff0000' style='font-size: 25px;';> Error!!</p>";
	}
?>
<!--
<!DOCTYPE html>
<head>
	 <title>Certificate Verification Portal</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="arun kumar">
    Bootstrap Core CSS 
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<style>
		.chip {
			display: inline-block;
			padding: 0 25px;
			height: 50px;
			font-size: 18px;
			line-height: 50px;
			border-radius: 0px;
			background-color: #f1f1f1;
		}
		.closebtn {
			padding-left: 10px;
			color: #888;
			font-weight: bold;
			float: right;
			font-size: 20px;
			cursor: pointer;
		}
		.closebtn:hover {
			color: #000;
		}
		.thanks_header{
			border-radius: 0px;
			height: 100px;
			padding: 22px;
		}
		.edumore_label{
			font-size: 30px;
		}
	</style>
</head>
<body>
    <!-- Navigation 
    <nav class="navbar navbar-inverse thanks_header" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display 
            <div class="navbar-header">
                <!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> 
                <a class="navbar-brand edumore_label" href="http://www.edumorelearning.com/">Edumore Learning</a>
            </div>
        </div>
        <!-- /.container 
    </nav>
	<div class="container-fluid">
	  <div class="alert alert-success alert-dismissable fade in">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<strong>&#x2714; Thanks !</strong> Our team member contact you as soon as possible after discern your information
	  </div>
	</div>
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript 
    <script src="js/bootstrap.min.js"></script>
</body>
</html> -->
