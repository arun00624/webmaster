<?php
	$subscriber_email=$_REQUEST['subscriber_email'];
	$subscriber_db=mysqli_connect("localhost","root","","edumore");
	$subscriber_query="INSERT INTO subscriber(subscriber_email,subscribe_date_time) values('$subscriber_email',NOW())";
	mysqli_query($subscriber_db,$subscriber_query);
	
	$subject = "Edumore Learning Newsletter";
	/*enter your domain mail id*/
	$from = 'arun00624@email.com';
			 
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			 
			// Create email headers
	$headers .= 'From: '.$from."\r\n".
				'Reply-To: '.$from."\r\n" .
				'X-Mailer: PHP/' . phpversion();
			 
			// Compose a HTML email message
	$message = "<html>
					<body>
						<h1 style='font-size: 20px; color: #008000;'>&#x2714; Subscription Successful!!</h1>
						<p>Thank you! You have successfully subscribe our newsletter. You'll be receiving notifications, latest news or courses offer from Edumore Learning Center</p>
						<p><font color='#008000' size='4'>Edumore Management Team</font></p>
						<p align='left'>website: www.edumorelearning.com</p>
						<img src='http://www.edumorelearning.com/pictures/edumore_logo.png' alt='edumore_logo'/>
					</body>
				</html>";
	if(mail($subscriber_email,$subject,$message,$headers)){
		echo "<h1 style='text-align: center; margin-top: 70px;'>
			<font style='color: #008000; display: inline; font-size: 25px;'><img src='images/success.png' height='50' alt='successful'/>Success! Thank you for subscribing our newsletter.</font>
		</h1>";
	}
	else{
		echo "<h1  style='text-align: center; font-size: 25px; margin-top: 70px;'><font color='#ff0000'> Error!!<br/> Can't subscribe newsletter. </br>Please try again.</p>";
	}
?>
<!DOCTYPE Html>
<head>
</head>
	<body>
		<?php include 'header1.php'; ?>
	</body>
</html>
