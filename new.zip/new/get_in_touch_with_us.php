<!DOCTYPE html>
<html lang="en">
<head>
	 <title>Certificate Verification Portal</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="arun kumar">
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<style>
		.chip {
			display: inline-block;
			padding: 0 25px;
			height: 50px;
			font-size: 18px;
			line-height: 50px;
			border-radius: 0px;
			background-color: #f1f1f1;
		}
		.closebtn {
			padding-left: 10px;
			color: #888;
			font-weight: bold;
			float: right;
			font-size: 20px;
			cursor: pointer;
		}
		.closebtn:hover {
			color: #000;
		}
		.thanks_header{
			border-radius: 0px;
			height: 100px;
			padding: 22px;
		}
		.edumore_label{
			font-size: 30px;
		}
	</style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse thanks_header" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> -->
                <a class="navbar-brand edumore_label" href="http://www.edumorelearning.com/">Edumore Learning</a>
            </div>
        </div>
        <!-- /.container -->
    </nav>
	<div class="container-fluid">
	  <div class="alert alert-success alert-dismissable fade in">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<strong>&#x2714; Thanks <?php $your_name; ?>!</strong> Our team member contact you as soon as possible after discern your information
	  </div>
	</div>
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
