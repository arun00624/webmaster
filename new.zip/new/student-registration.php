<!DOCTYPE html>
<html>
	<head>
		<title>Student Registration Form</title>
	</head>
	<body>
			<?php 
				include 'header1.php';
			?>
			<div class="container">
				<h3 align="center">Student Registration Form</h3>
				<form method="post" action="student-registration-status.php" class="form-horizontal career_form_container">
					<div class="form-group">
					 <h6 align="right" class="error" style="margin-right: 16px; color: #f00;">* indicates required fields</h6>
					  <label class="control-label col-sm-3" for="student_course">Course Enrolling For: <span>*</span></label>
					  <div class="col-sm-9">          
						<select name="student_course" class="form-control" id="student_course" required="required">
							<option value="">-- Select Course --</option>
							<option value="C Language">C Language</option>
							<option value="C++">C++ Language</option>
							<option value="Core Java">Core Java</option>
							<option value="Advance Java">Advance Java</option>
							<option value="Java BlueJ">BlueJ</option>
							<option value="Core Php">Core php</option>
							<option value="Advance Php">Advance Php</option>
							<option value="Web Designing">Web Designing</option>
							<option value="Web Development">Web Development</option>
							<option value="Asp.net(C#)">Asp.net(c#)</option>
							<option value="Digital Marketing(SEO)">Digital Marketing(SEO)</option>
							<option value="Mysql">Mysql</option>
							<option value="Oracle">Oracle Databse</option>
							<option value="Android">Android</option>
							<option value="Software Testing">Software Testing</option>
							<option value="Ethical Hacking">Ethical Hacking</option>
							<option value="CCNA">CCNA(Cisco Certified Network Associate)</option>
							<option value="CCNP">CCNP(Cisco Certified Network Professional)</option>
							<option value="MCSA">MCSA(Microsoft Certified Solutions Associate)</option>
							<option value="Red hat(LINUX)">RHCE(Red Hat Certified Engineer)</option>
							<option value="A+">A+(Hardware)</option>
							<option value="MIS">MIS(Management Information System)</option>
							<option value="MS Office">MS Office</option>
							<option value="Tally Erp9">Tally Erp9</option>
							<option value="Basic Computer Course">Basic Computer Course</option>
						</select>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_name">Student Name:<span>*</span></label>
					  <div class="col-sm-9">
						<input type="text" name="student_name" class="form-control" id="student_name" required="required" placeholder="Enter Your Name"/>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_mob">Mobile No:<span>*</span></label>
					  <div class="col-sm-9">          
						<input type="number" name="student_mob" class="form-control student_mob" id="student_mob" required="required" placeholder="Enter Your Mobile No"/>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_email">Email ID:<span>*</span></label>
					  <div class="col-sm-9">          
						<input type="email" name="student_email" class="form-control" id="student_email" required="required" placeholder="Enter Your Email ID"/>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_gender">Gender:<span>*</span></label>
					  <div class="col-sm-9">          
						<select name="student_gender" class="form-control" id="student_gender" required="required">
							<option value="">-- Select Gender --</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
						</select>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_highest_qualification">Highest Qualification:<span>*</span></label>
					  <div class="col-sm-9">
						<input type="text" name="student_highest_qualification" class="form-control" id="student_highest_qualification" required="required" placeholder="Enter Your Highest Qualification"/>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_current_address">Current Address:</label>
					  <div class="col-sm-9">          
						<textarea name="student_current_address" class="address_textarea form-control" id="student_current_address" rows="6" placeholder="Enter Your Current Address..."></textarea>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-3" for="student_message">Your Message:</label>
					  <div class="col-sm-9">          
						<textarea name="student_message" class="message_textarea form-control" id="student_message" rows="4" placeholder="Enter Your Message Here..."></textarea>
					  </div>
					</div>	 
					<div class="form-group">        
					  <div class="col-sm-offset-3 col-sm-9">
						<button type="submit" class="btn btn-success btn-sm load_button">Register</button>
						<button type="reset" class="btn btn-primary btn-sm">Clear</button>
					  </div>
					</div>
				</form>
		    </div>
	</body>
</html>