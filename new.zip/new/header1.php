<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<!-- to be filled -->
		<meta name="keywords" content=""> 
		<!-- css files -->
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/footer-pic.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/jQuery.lightninBox.css" rel="stylesheet" type="text/css" media="all">
		<link href="css/staff.css" rel="stylesheet" type="text/css" media="all">
		<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all">
		<link href="css/style1.css" rel="stylesheet" type="text/css" media="all">
		<!-- /css files -->
	</head>
	<body>
		<div class="navbar-wrapper">
			<div class="container-fluid">
				<nav class="navbar navbar-inverse navbar-static-top">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.php"><h1 class="edumore_label">Edumore Learning</h1></a>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a href="index.php" class="page-scroll" data-hover="Home">Home</a></li>
							<li><a href="index.php#about" class="page-scroll" data-hover="About">About</a></li>
							<li><a href="index.php#service" class="page-scroll" data-hover="Services">Courses</a></li>
							<li><a href="index.php#team" class="page-scroll" data-hover="Team">Team</a></li>
							<li><a href="index.php#portfolio" class="page-scroll" data-hover="Portfolio">Portfolio</a></li>
							<li><a href="index.php#contact" class="page-scroll" data-hover="Contact">Contact</a></li>
							<li><a href="student-registration.php" class="page-scroll">Registration</a></li>
							<li><a href="check-your-certificate-online.php" class="page-scroll">Certification</a></li>
						</ul>
					</div>
				</nav>
			</div>	
		</div>
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/SmoothScroll.min.js"></script>
		<script src="js/modernizr.min.js"></script> 
		<script src="js/jquery.easing.min.js"></script>
		<script src="js/grayscale.js"></script>
		<script src="js/jqBootstrapValidation.js"></script>
		<script src="js/top.js"></script>
		<!-- js for banner section -->
		<script src="js/bgfader.js"></script>
		<script>
			var myBgFader = $('.header').bgfader([
			'images/banner1.jpg',
			'images/banner2.jpg',
			'images/banner3.jpg',
			'images/banner4.jpg',
			], {
			'timeout': 3000,
			'speed': 3000,
			'opacity': 0.4
			})
			myBgFader.start()
		</script>
		<!-- /js for banner section -->
		<!-- js for parallax effect -->
		<script src="js/jarallax.js"></script>
		<script type="text/javascript">
			/* init Jarallax */
			$('.jarallax').jarallax({
				speed: 0.5,
				imgWidth: 1366,
				imgHeight: 768
			})
		</script>
		<!-- /js for parallax effect -->
		<!-- js for footer pic lightbox -->
		<script src="js/jquery.picEyes.js"></script>
		<script>
		$(function(){
			//picturesEyes($('li'));
			$('ul.demo li').picEyes();
		});
		</script>
		<!-- /js for footer pic lightbox -->
		<!-- js for portfolio lightbox -->
		<script src="js/jQuery.lightninBox.js"></script>
		<script type="text/javascript">
			$(".lightninBox").lightninBox();
		</script>
		<!-- /js for portfolio lightbox -->
		<script src='js/aos.js'></script>
		<script src="js/index.js"></script>
		<!-- /js files -->	
	</body>
</html>