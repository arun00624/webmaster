<!DOCTYPE html>
<html>
	<head>
		<title>C and C++ Language Training | Edumore Learning</title>
		<link rel="icon" href="images/edumore_favicon.png" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="css/course_style.css">
	</head>
	<body>	
		<?php include 'header1.php'; ?>
		<div class="container-fluid">
			<p class="course_heading">Our C and C++ Language Training</p>
			<div class="row">
				<div class="col-sm-12">
					<img src="images/course_check/c_and_c++_first_step.jpg" alt="c_language_description" class="img-responsive"/>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-12">
					<h2 class="course_intro">C introduction</h2>
					<p><b>1) </b>C is a general purpose high level programming language which is developed by <b>Dennis M. Ritche</b> at <b>At & T Bell Labs, USA in 1972</b>. Initially it was invented to develop UNIX OS and C is successor of BCPL also called B language.</p>
					<p><b>2) </b>In 1978, Brian <b>Kernighan and Dennis Ritchie</b> produced the first publicly available description of C, now known as the <b>K&R standard</b>.</p>
					<p><b>3) </b>C belongs to the structured, procedural paradigms of languages. It is proven, flexible and powerful and may be used for a variety of different applications. Although high-level, C and assembly language share many of the same attributes.</p>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-6">
					<p>Some of C's most important features include:</p>
					<p>&#9758; Fixed number of keywords, including a set of control primitives, such as if, for, while, switch and do while.</p>
					<p>&#9758; Multiple logical and mathematical operators, including bit manipulators.</p>
					<p>&#9758; Multiple assignments may be applied in a single statement.</p>
					<p>&#9758; Function return values are not always required and may be ignored if unneeded.</p>
					<p>&#9758; Typecasting is static. All data has type but may be implicitly converted.</p>
					<p>&#9758; Basic form of modularity, as files may be separately compiled and linked.</p>
					<p>&#9758; Control of function and object visibility to other files via extern and static attributes.</p>
				</div>
				<div class="col-sm-6">
					<img src="images/course_check/c_and_c++.png" alt="c_language_description" class="img-responsive"/>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-6">
					<img src="images/course_check/c-programming.jpg" alt="c_language_description" class="img-responsive"/>
				</div>
				<div class="col-sm-6">
					<h2 class="course_intro">What are the usage of C Language?</h2>
					<p>&#9758; Operating Systems (Windows, Linux, Android, iOS)</p>
					<p>&#9758; Database systems</p>
					<p>&#9758; Language Compilers, Interpreters and Assemblers</p>
					<p>&#9758; Network Drivers</p>
					<p>&#9758; Spreadsheets</p>
					<p>&#9758; Word processors</p>
					<p>&#9758; Embedded Systems</p>
				</div>
			</div>
			<p class="register_c_button">
               <a href="student-registration.php" class="btn btn-outlined btn-theme" data-wow-delay="0.7s">Register Yourself For C &rarr;</a>
            </p>
		</div>
		<hr width="100%" style="border: 1px solid #00d9d9"/>
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12">
					<img src="images/course_check/c++5.png" alt="c++_description" class="img-responsive"/>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-12">
					<h2 class="course_intro">C++ introduction</h2>
					<p><b>1) </b>it is a general purpose and case sensitive programming language.</p>
					<p><b>2) </b>it is an <b>object-oriented programming language</b>, It is an extension to C programming.</p>
 					<p><b>3) </b>it is developed by <b>Bjarne Stroustrup </b>and founded in 1979 at <b>Bell Labs.</b></p>
					<p><b>4) </b>C++ consider as middle-level language because it comprises(includes) a combination of both high-level and low-level language features.</p>
					<p><b>5) </b>it is enhanced c language and initially it was C with classes but later in 1983, it was renamed as c++.</p>
				</div>
			</div>
			<div class="row cplus_plus_description">
				<div class="col-sm-6">
					<p>Some of C++ most important features are:</p>
					<p>&#9758; Object oriented oriented</p>
					<p>&#9758; Simple</p>
					<p>&#9758; Portability</p>
					<p>&#9758; Powerful</p>
					<p>&#9758; Platform dependent</p>
					<p>&#9758; Compiler based</p>
					<p>&#9758; Use of Pointers</p>
					<p>&#9758; Syntax based language</p>
				</div>
				<div class="col-sm-6">
					<img src="images/course_check/c++_features.jpg" alt="cplus_plus_description" class="img-responsive"/>
				</div>
			</div>
			<div class="row c_description">
				<div class="col-sm-6">
					<img src="images/course_check/c++6.jpg" alt="cplus_plus_description" class="img-responsive"/>
				</div>
				<div class="col-sm-6">
					<h2 class="course_intro">What are the usage of C++ Language?</h2>
					<p>&#9758; Games</p>
					<p>&#9758; Graphic User Interface (GUI) based applications</p>
					<p>&#9758; Web Browsers</p>
					<p>&#9758; Advance Computations and Graphics</p>
					<p>&#9758; Database Software</p>
					<p>&#9758; Operating Systems</p>
					<p>&#9758; Enterprise Software</p>
					<p>&#9758; Medical and Engineering Applications</p>
					<p>&#9758; Compilers</p>
				</div>
			</div>
			<p class="register_c_button">
               <a href="student-registration.php" class="btn btn-outlined btn-theme" data-wow-delay="0.7s">Register Yourself For C++ &rarr;</a>
            </p>
		</div>
		<div class="content">
		</div>
		<footer id="myFooter">
			<div class="container">
				<div class="row">
					<div class="col-sm-3 myCols">
						<h5>Home</h5>
						<ul>
							<li><a href="index.php">Home Page</a></li>
							<li><a href="index.php#team">Our Team Members</a></li>
							<li><a href="index.php#portfolio">Our Portfolio</a></li>
						</ul>
					</div>
					<div class="col-sm-3 myCols">
						<h5>About us</h5>
						<ul>
							<li><a href="index.php#about">About Training Centre</a></li>
							<li><a href="index.php#contact">Contact us</a></li>
							<li><a href="index.php#footer">Reviews</a></li>
						</ul>
					</div>
					<div class="col-sm-3 myCols">
						<h5>Courses Offered</h5>
						<ul>
							<li><a href="index.php#service">Software Training programs</a></li>
							<li><a href="index.php#service">Networking Programs</a></li>
							<li><a href="index.php#service">Accounts Training programs</a></li>
						</ul>
					</div>
					<div class="col-sm-3 myCols">
						<h5>Others</h5>
						<ul>
							<li><a href="check-your-certificate-online.php">verify certificate</a></li>
							<li><a href="student-registration.php">Student Registration</a></li>
							<li><a href="http://edumorelearning.blogspot.in/">Blog</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="social-networks">
				<a href="https://twitter.com/edumoreindia" class="twitter"><i class="fa fa-twitter"></i></a>
				<a href="https://www.facebook.com/6WeeksProjectTraining/" class="facebook"><i class="fa fa-facebook-official"></i></a>
				<a href="https://plus.google.com/+EdumorelearningIT" class="google"><i class="fa fa-google-plus"></i></a>
			</div>
			<div class="footer-copyright">
				<p>Copyright © 2017 @edumorelearning</p>
			</div>
		</footer>
	</body>
</html>
	