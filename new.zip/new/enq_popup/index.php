<!DOCTYPE Html>
<html>
	<head>
		<title>Enquiry Form</title>
		<!-- Latest minified bootstrap css -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

		<!-- Latest minified bootstrap js -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<!--- Custom Jquery Code --->
		<script type="text/javascript" src="jq/popup.js"></script>
		<style>
			.headerBg{
				background-color: green;
				color: #fff;
			}
			.closeBg{
				color: #fff;
			}
		</style>
	</head>
	<body>
		<!-- Modal -->
		<div class="modal fade" id="EnquiryForm" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<!-- Modal Header -->
					<div class="modal-header headerBg">
						<button type="button" class="close" data-dismiss="modal">
							<span aria-hidden="true" class="closeBg">&times;</span>
							<span class="sr-only">Close</span>
						</button>
						<h4 class="modal-title" align="center" id="myModalLabel">Quick Enquiry @9871537861</h4>
					</div>
					
					<!-- Modal Body -->
					<div class="modal-body">
						<h4 class="statusMsg"></h4>
						<form role="form" method="post">
							<div class="form-group">
								<label for="inputName">Name</label>
								<input type="text" class="form-control" id="inputName" placeholder="Enter your name"/>
							</div>
							<div class="form-group">
								<label for="inputEmail">Email</label>
								<input type="email" class="form-control" id="inputEmail" placeholder="Enter your email"/>
							</div>
							<div class="form-group">
								<label for="inputMobile">Mobile Number</label>
								<input type="text" class="form-control" id="inputMobile" placeholder="Enter your mobile no"/>
							</div>
							<div class="form-group">
								<label for="inputMessage">Message</label>
								<textarea class="form-control" id="inputMessage" placeholder="Enter your message"></textarea>
							</div>
						</form>
					</div>
					
					<!-- Modal Footer -->
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary submitBtn" onclick="submitContactForm()">SUBMIT</button>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>