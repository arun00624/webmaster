<!DOCTYPE html>
<html>
	<head>
		  <title>Wish you a happy republic day 2018 | Edumore Learning</title>
		  <meta charset="utf-8">
		  <meta name="viewport" content="width=device-width, initial-scale=1">
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		  <link rel="icon" href="images/edumore_favicon.png" type="image/x-icon">
		  <style>
			body{
				background: linear-gradient(red,white,green);
			}
		  </style>
	</head>
	<body>
		<div>
			<img src="images/shiv_image.gif" alt="we wish you a happy mahashivratri 2018" title="Maha Shivratri" class="img-responsive"/>
			<img src="images/shiv_quotes.png" alt="we wish you a happy mahashivratri 2018" title="Maha Shivratri" class="img-responsive"/>
		</div>
	</body>
</html>