<!DOCTYPE html>
<html lang="en">
<head>
  <title>Certificate verification portal | Edumore Learning</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
  <link rel="stylesheet" type="text/css" href="css/edumore_custom.css">
  <link rel="icon" href="images/verified_glyphicon.png" type="image/x-icon">
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a class="navbar-brand" href="#">Edumore Learning</a>
		</div>
		<!--<ul class="nav navbar-nav">
		  <li><a href="">Certificate can be verified from here</a></li>
		</ul> -->
	  </div>
	</nav>
	<div class="search_registration_id_div effect" style="margin-top:50px">
		<div class="container">
			<form action="verify-certificate.php" method="post" class="form-horizontal">
				<div class="form-group">
					<label class="control-label col-sm-2 registration_label" for="registration_no">Registration No:</label>
					<div class="col-lg-8">
						<input type="text" name="registration_no" class="form-control registration_no_textbox" id="registration_no" placeholder="Enter Your Registration No" required="required"/>
					</div>
					<div class="col-sm-2 verify_button">
						<input type="submit" class="btn btn-success" value="Verify Certificate"/>
					</div>
				</div>
				
			</form>
		</div>
			
	</div>
</body>
</html>
