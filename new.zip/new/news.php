<!DOCTYPE html>
<html>
	<head>
		  <title>Today's News | Edumore Learning</title>
		  <meta charset="utf-8">
		  <meta name="viewport" content="width=device-width, initial-scale=1">
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
		  <link rel="icon" href="images/edumore_favicon.png" type="image/x-icon">
		  <style>
			a{
				text-decoration: none;
			}
			li{
				line-height: 2;
			}
		  </style>
	</head>
	<body>
		<?php include 'header1.php' ?>
		<div>
			<a href="https://www.edumorelearning.com/index#service">
				<h1 align='center'>#Today's News Headlines</h1>
				<ol type="square">
					<li>आज दोनों सदनों में PM मोदी का संबोधन, क्या राफेल डील पर बोलेंगे?</li>
					<li>मालदीव: राष्ट्रपति के आगे SC का सरेंडर, 9 नेताओं की रिहाई पर रोक</li>
					<li>PICS: जब पानी के 6 मीटर नीचे हुई राष्ट्रपति-मंत्रियों की मीटिंग</li>
					<li>राफेल की लागत गोपनीय बता रही सरकार, 2016 में बता चुकी है कीमत</li>
					<li>विकास गुप्ता के हाथ लगा बड़ा जैकपॉट, इस शो में करेंगे शिरकत</li>
					<li>खौफ में दक्षिण अफ्रीका, भारतीय स्पिन से निपटने के लिए की तैयारी</li>
					<li>ताइवान में भूकंप से दहशत, 2 की मौत, अब तक आए 100 झटके</li>
					<li>बोल्ड फोटो पर Troll बंदगी कालरा, लोगों ने किए भद्दे कमेंट</li>
					<li>बेंगलुरु मेट्रो में लोग कर रहे ये अजीब हरकत, जानकर चौंक जाएंगे आप</li>
					<li>CBSE बोर्ड: 10वीं,12वीं के एडमिट कार्ड जारी, ऐसे करें डाउनलोड</li>
					<li>कटरीना की बहन का रणबीर से है खास कनेक्शन</li>
					<li>दिल्ली: पुलिस ने एनकाउंटर के बाद पकड़े मिर्ची गैंग के बदमाश</li>
				</ol>
			</a>
		</div>
	</body>
</html>